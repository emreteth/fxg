ort1 = int(input("1.sınav : "))
ort2 = int(input("2.sınav : "))
ort3 = int(input("1.sözlü : "))
ort4 = int(input("2.sözlü : "))


ort5 = ort1+ort2+ort3+ort4
ort6 = ort5/4

print("\nortalama ",ort6)
